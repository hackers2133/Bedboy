npm init - y
npm install express nodemailer